import {
  Die
} from './Die.js'

export class DiceSet {
  constructor(diceCount, player) {
    this.player = player,
      this.diceCount = diceCount,
      this.dice = this.createDice(this.diceCount).map(id => new Die(id, this)),
      this.activeDice = this.getActiveDice(),
      this.keptCount = 0,
      this.selectedValue = []
  }

  createDice(count) {
    let die = [];
    for (let i = 1; i <= count; i++) {
      let id = i;
      die.push(id);
    };
    return die;
  }
  renderDice() {
    const rollArea = document.querySelector(`.rollDisplay`);

    const diceMarkup = document.createElement('div');
    diceMarkup.classList.add('dice')
    this.dice.forEach(die => {
      die.newTemplate();

      diceMarkup.appendChild(die.dieElement)
    })
    rollArea.appendChild(diceMarkup)

    const dieElems = document.querySelectorAll(`.die-list`);
    dieElems.forEach(die => {
      this.registerDiceListener(die)
    })

  }
  registerDiceListener(el) {

    // let el = this.dieElement;
    el.addEventListener('click', e => {
    let keptDice = this.player.keptDice;
    this.getSelectedDice();

      let keptCheck = keptDice.every(d => {
        return d.dataset.roll == el.dataset.roll;
      })
      console.log('keptCheck');
      console.log(keptCheck);
      console.log(keptDice);
      let selectedCheck = this.selectedDice.every(d => {
        return d.dataset.roll == el.dataset.roll;
      })
      console.log('selectedCheck');
      console.log(selectedCheck);
      console.log(this.selectedDice);
      if (keptCheck === true && selectedCheck === true) {

        el.classList.toggle('selected')
        if (keptCheck === false) {

        }
        const dieSides = [...el.children];
        dieSides.forEach(child => {
          child.classList.toggle('selected')

          const dots = [...child.children];
          dots.forEach(dot => {
            dot.classList.toggle('selected')
          })
        })
      
      if (el.classList.contains('selected')) {
        el.dataset.selected = 'true';
      } else {
        el.dataset.selected = 'false';
      }
      console.log(el);
}
    })
  }
  // renderRolls(rollAreaSelector) {
  //   const rollArea = document.querySelector(`.${rollAreaSelector}`);
  //   const keptArea = document.querySelector(`.keptDisplay`);
  //   const activeDice = this.getActiveDice()
  //   const keptDice = this.getKeptDice()


  //   let keptDiceMarkup = keptDice //* get the html template for each kept die and reduce it to single html string
  //     .reduce((acc, curr) => {
  //       curr.createTemplate()
  //       return acc += curr.template;
  //     }, '');
  //   keptArea.innerHTML = keptDiceMarkup;

  //   // let activeDiceMarkup = activeDice //* get the html template for each active (unkept) die and reduce it to single html string
  //   //   .reduce((acc, curr) => {
  //   //     return acc += curr.template;
  //   //   }, '');
  //   // rollArea.innerHTML = activeDiceMarkup;

  //   // activeDice.forEach(die => {
  //   //   die.registerEventListener(`.${die.id}Value`);
  //   // })
  // }

  getActiveDice() {
    let activeArray = [...document.querySelectorAll(`.die-list`)]
      .filter(die => die.dataset.kept === false)
    this.activeDice = activeArray;
    return this.activeDice;
  }

  getKeptDice() {
    let keptArray = [...document.querySelectorAll(`.die-list`)]
      .filter(die => {
        return die.dataset.kept === true;
      })
    this.keptDice = keptArray;
    return this.keptDice;
  }

  getSelectedDice() {
    let selected = [...document.querySelectorAll(`.die-list`)]
      .filter(die => {
        return die.dataset.selected === 'true';
      })
    this.selectedDice = selected
    return selected;
  }

  getKeptCount() {
    this.keptCount = this.keptDice.length;
    return this.keptCount;
  }
}

{
  DiceSet
}